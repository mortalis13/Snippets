namespace IntegralUI_WinForms_Samples
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            LidorSystems.IntegralUI.Style.ControlColorStyle controlColorStyle2 = new LidorSystems.IntegralUI.Style.ControlColorStyle();
            LidorSystems.IntegralUI.Style.ControlFormatStyle controlFormatStyle2 = new LidorSystems.IntegralUI.Style.ControlFormatStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.treeView1 = new LidorSystems.IntegralUI.Lists.TreeView();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.labelInfo = new LidorSystems.IntegralUI.Controls.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.treeView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            // 
            // 
            // 
            this.treeView1.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.treeView1.ContentPanel.Location = new System.Drawing.Point(3, 3);
            this.treeView1.ContentPanel.Name = "";
            this.treeView1.ContentPanel.Size = new System.Drawing.Size(384, 357);
            this.treeView1.ContentPanel.TabIndex = 3;
            this.treeView1.ContentPanel.TabStop = false;
            this.treeView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(5, 5);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(390, 363);
            this.treeView1.TabIndex = 0;
            this.treeView1.Text = "treeView1";
            this.treeView1.AfterCollapse += new LidorSystems.IntegralUI.ObjectEventHandler(this.treeView1_AfterCollapse);
            this.treeView1.AfterExpand += new LidorSystems.IntegralUI.ObjectEventHandler(this.treeView1_AfterExpand);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(403, 11);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(111, 23);
            this.btnChange.TabIndex = 1;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(403, 40);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(111, 23);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // labelInfo
            // 
            this.labelInfo.BackColor = System.Drawing.Color.Transparent;
            controlColorStyle2.BackColor = System.Drawing.Color.LightYellow;
            controlColorStyle2.BackFadeColor = System.Drawing.Color.Ivory;
            this.labelInfo.ColorStyle = controlColorStyle2;
            controlFormatStyle2.Padding = new System.Windows.Forms.Padding(5);
            this.labelInfo.FormatStyle = controlFormatStyle2;
            this.labelInfo.Location = new System.Drawing.Point(5, 374);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(509, 150);
            this.labelInfo.TabIndex = 3;
            this.labelInfo.Text = "label1";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folder1.ico");
            this.imageList1.Images.SetKeyName(1, "folder2.ico");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 529);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.treeView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IntegralUI TreeView - Change Image of Expand Button";
            ((System.ComponentModel.ISupportInitialize)(this.treeView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private LidorSystems.IntegralUI.Lists.TreeView treeView1;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnReset;
        private LidorSystems.IntegralUI.Controls.Label labelInfo;
        private System.Windows.Forms.ImageList imageList1;
    }
}