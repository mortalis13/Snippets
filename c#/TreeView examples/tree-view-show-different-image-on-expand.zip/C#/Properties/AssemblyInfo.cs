﻿//                                                                  
// Copyright © 2013 Lidor Systems.
// All Rights Reserved.
//
// This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
// either express or implied.                        
//

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TreeView-Change-Expand-Image")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lidor Systems")]
[assembly: AssemblyProduct("TreeView-Change-Expand-Image")]
[assembly: AssemblyCopyright("Copyright © Lidor Systems 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fd075ece-f5e2-4f79-bc0d-65c1abf55593")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
