//                                                                  
// Copyright � 2013 Lidor Systems.
// All Rights Reserved.
//
// This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
// either express or implied.                        
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IntegralUI_WinForms_Samples
{
    public partial class Form1 : Form
    {
        #region Variables
        private int[] randomInts = null;
        private int nodeCount = 0;
        #endregion

        #region Initialization
        public Form1()
        {
            InitializeComponent();

            CreateLabelContent();

            InitList();
        }

        private void CreateLabelContent()
        {
            String content = "<div style=\"font:Verdana,9,r\"><p>In this sample we are showing how to change default appearance of expand buttons.</p><br></br>";
            content += "<p>IntegralUI TreeView has a style called <b>ExpandBoxStyle</b> with which you can customize the appearance of expand buttons. For this example we are using the <b>ExpandImage</b> and <b>CollapseImage</b> properties which if used will replace the default look of expand button in its expanded and collapsed state</p><br></br>";
            content += "<p>You can assign any image in any custom size, and the node layout will adjust accordingly to image size.</p>";
            content += "</div>";

            this.labelInfo.Content = content;
        }

        private void InitList()
        {
            this.treeView1.SuspendUpdate();

            nodeCount = 0;
            randomInts = CreateRandomInts();

            CreateNode(this.treeView1.RootNode, "", 0);

            this.treeView1.ResumeUpdate();
        }

        private void CreateNode(LidorSystems.IntegralUI.Lists.TreeNode parentNode, String prefix, int level)
        {
            if (level == 5)
                return;

            int limit = randomInts[nodeCount % 99];
            if (level == 0)
                limit = 100;

            LidorSystems.IntegralUI.Lists.TreeNode node = null;
            for (int i = 1; i <= limit; i++)
            {
                node = new LidorSystems.IntegralUI.Lists.TreeNode("Node " + prefix + i.ToString());

                parentNode.Nodes.Add(node);
                nodeCount++;

                CreateNode(node, prefix + i.ToString(), level + 1);
            }
        }

        private int[] CreateRandomInts()
        {
            int[] rand = new int[100];
            Random gen = new Random();
            for (int i = 0; i < rand.Length; i++)
                rand[i] = gen.Next(0, 5);

            return rand;
        }
        #endregion

        #region Events
        private void btnChange_Click(object sender, EventArgs e)
        {
            this.treeView1.ExpandBoxStyle.ExpandImage = Image.FromFile("../../../Demo/expand.gif");
            this.treeView1.ExpandBoxStyle.CollapseImage = Image.FromFile("../../../Demo/collapse.gif");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.treeView1.ExpandBoxStyle.Reset();
            this.treeView1.Invalidate();
        }

        private void treeView1_AfterExpand(object sender, LidorSystems.IntegralUI.ObjectEventArgs e)
        {
            // Change the icon of the node to show open folder after node gets expanded
            if (e.Object is LidorSystems.IntegralUI.Lists.TreeNode)
            {
                LidorSystems.IntegralUI.Lists.TreeNode node = (LidorSystems.IntegralUI.Lists.TreeNode)e.Object;

                // Set the same image when node is selected or not selected
                node.ImageIndex = 1;
                node.SelectedImageIndex = 1;
            }
        }

        private void treeView1_AfterCollapse(object sender, LidorSystems.IntegralUI.ObjectEventArgs e)
        {
            // Change the icon of the node to show closed folder after node gets collapsed
            if (e.Object is LidorSystems.IntegralUI.Lists.TreeNode)
            {
                LidorSystems.IntegralUI.Lists.TreeNode node = (LidorSystems.IntegralUI.Lists.TreeNode)e.Object;

                // Set the same image when node is selected or not selected
                node.ImageIndex = 0;
                node.SelectedImageIndex = 0;
            }
        }
        #endregion
    }
}