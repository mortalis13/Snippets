<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim ControlColorStyle1 As LidorSystems.IntegralUI.Style.ControlColorStyle = New LidorSystems.IntegralUI.Style.ControlColorStyle
        Dim ControlFormatStyle1 As LidorSystems.IntegralUI.Style.ControlFormatStyle = New LidorSystems.IntegralUI.Style.ControlFormatStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.labelInfo = New LidorSystems.IntegralUI.Controls.Label
        Me.btnReset = New System.Windows.Forms.Button
        Me.btnChange = New System.Windows.Forms.Button
        Me.treeView1 = New LidorSystems.IntegralUI.Lists.TreeView
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.labelInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.treeView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'labelInfo
        '
        Me.labelInfo.BackColor = System.Drawing.Color.Transparent
        ControlColorStyle1.BackColor = System.Drawing.Color.LightYellow
        ControlColorStyle1.BackFadeColor = System.Drawing.Color.Ivory
        Me.labelInfo.ColorStyle = ControlColorStyle1
        ControlFormatStyle1.Padding = New System.Windows.Forms.Padding(5)
        Me.labelInfo.FormatStyle = ControlFormatStyle1
        Me.labelInfo.Location = New System.Drawing.Point(5, 374)
        Me.labelInfo.Name = "labelInfo"
        Me.labelInfo.Size = New System.Drawing.Size(509, 150)
        Me.labelInfo.TabIndex = 7
        Me.labelInfo.Text = "label1"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(403, 40)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(111, 23)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnChange
        '
        Me.btnChange.Location = New System.Drawing.Point(403, 11)
        Me.btnChange.Name = "btnChange"
        Me.btnChange.Size = New System.Drawing.Size(111, 23)
        Me.btnChange.TabIndex = 5
        Me.btnChange.Text = "Change"
        Me.btnChange.UseVisualStyleBackColor = True
        '
        'treeView1
        '
        '
        '
        '
        Me.treeView1.ContentPanel.BackColor = System.Drawing.Color.Transparent
        Me.treeView1.ContentPanel.Location = New System.Drawing.Point(3, 3)
        Me.treeView1.ContentPanel.Name = ""
        Me.treeView1.ContentPanel.Size = New System.Drawing.Size(384, 357)
        Me.treeView1.ContentPanel.TabIndex = 3
        Me.treeView1.ContentPanel.TabStop = False
        Me.treeView1.Cursor = System.Windows.Forms.Cursors.Default
        Me.treeView1.ImageIndex = 0
        Me.treeView1.ImageList = Me.imageList1
        Me.treeView1.Location = New System.Drawing.Point(5, 5)
        Me.treeView1.Name = "treeView1"
        Me.treeView1.SelectedImageIndex = 0
        Me.treeView1.Size = New System.Drawing.Size(390, 363)
        Me.treeView1.TabIndex = 4
        Me.treeView1.Text = "treeView1"
        '
        'imageList1
        '
        Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.imageList1.Images.SetKeyName(0, "folder1.ico")
        Me.imageList1.Images.SetKeyName(1, "folder2.ico")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(519, 529)
        Me.Controls.Add(Me.labelInfo)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnChange)
        Me.Controls.Add(Me.treeView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IntegralUI TreeView - Change Image of Expand Button"
        CType(Me.labelInfo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.treeView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents labelInfo As LidorSystems.IntegralUI.Controls.Label
    Private WithEvents btnReset As System.Windows.Forms.Button
    Private WithEvents btnChange As System.Windows.Forms.Button
    Private WithEvents treeView1 As LidorSystems.IntegralUI.Lists.TreeView
    Private WithEvents imageList1 As System.Windows.Forms.ImageList

End Class
