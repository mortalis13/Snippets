﻿'                                                                  
' Copyright © 2013 Lidor Systems.
' All Rights Reserved.
'
' This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
' either express or implied.                        
'

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("TreeView-Change-Expand-Image")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Lidor Systems")> 
<Assembly: AssemblyProduct("TreeView-Change-Expand-Image")> 
<Assembly: AssemblyCopyright("Copyright © Lidor Systems 2013")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: Guid("ba448eec-dc26-41c1-b7f8-14d1407f7352")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
