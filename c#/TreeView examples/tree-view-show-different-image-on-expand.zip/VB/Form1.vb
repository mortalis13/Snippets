'                                                                  
' Copyright � 2013 Lidor Systems.
' All Rights Reserved.
'
' This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
' either express or implied.                        
'

Public Class Form1

#Region "Variables"
    Private randomInts As Integer() = Nothing
    Private nodeCount As Integer = 0
#End Region

#Region "Initialization"
    Public Sub New()
        InitializeComponent()

        CreateLabelContent()

        InitList()
    End Sub

    Private Sub CreateLabelContent()
        Dim content As [String] = "<div style=""font:Verdana,9,r""><p>In this sample we are showing how to change default appearance of expand buttons.</p><br></br>"
        content += "<p>IntegralUI TreeView has a style called <b>ExpandBoxStyle</b> with which you can customize the appearance of expand buttons. For this example we are using the <b>ExpandImage</b> and <b>CollapseImage</b> properties which if used will replace the default look of expand button in its expanded and collapsed state</p><br></br>"
        content += "<p>You can assign any image in any custom size, and the node layout will adjust accordingly to image size.</p>"
        content += "</div>"

        Me.labelInfo.Content = content
    End Sub

    Private Sub InitList()
        Me.treeView1.SuspendUpdate()

        nodeCount = 0
        randomInts = CreateRandomInts()

        CreateNode(Me.treeView1.RootNode, "", 0)

        Me.treeView1.ResumeUpdate()
    End Sub

    Private Sub CreateNode(ByVal parentNode As LidorSystems.IntegralUI.Lists.TreeNode, ByVal prefix As [String], ByVal level As Integer)
        If level = 5 Then
            Return
        End If

        Dim limit As Integer = randomInts(nodeCount Mod 99)
        If level = 0 Then
            limit = 100
        End If

        Dim node As LidorSystems.IntegralUI.Lists.TreeNode = Nothing
        For i As Integer = 1 To limit
            node = New LidorSystems.IntegralUI.Lists.TreeNode("Node " & Convert.ToString(prefix) & i.ToString())

            parentNode.Nodes.Add(node)
            nodeCount += 1

            CreateNode(node, Convert.ToString(prefix) & i.ToString(), level + 1)
        Next
    End Sub

    Private Function CreateRandomInts() As Integer()
        Dim rand As Integer() = New Integer(99) {}
        Dim gen As New Random()
        For i As Integer = 0 To rand.Length - 1
            rand(i) = gen.[Next](0, 5)
        Next

        Return rand
    End Function
#End Region

#Region "Events"
    Private Sub btnChange_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnChange.Click
        Me.treeView1.ExpandBoxStyle.ExpandImage = Image.FromFile("../../../Demo/expand.gif")
        Me.treeView1.ExpandBoxStyle.CollapseImage = Image.FromFile("../../../Demo/collapse.gif")
    End Sub

    Private Sub btnReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReset.Click
        Me.treeView1.ExpandBoxStyle.Reset()
        Me.treeView1.Invalidate()
    End Sub

    Private Sub treeView1_AfterExpand(ByVal sender As Object, ByVal e As LidorSystems.IntegralUI.ObjectEventArgs) Handles treeView1.AfterExpand
        ' Change the icon of the node to show open folder after node gets expanded
        If TypeOf e.[Object] Is LidorSystems.IntegralUI.Lists.TreeNode Then
            Dim node As LidorSystems.IntegralUI.Lists.TreeNode = DirectCast(e.[Object], LidorSystems.IntegralUI.Lists.TreeNode)

            ' Set the same image when node is selected or not selected
            node.ImageIndex = 1
            node.SelectedImageIndex = 1
        End If
    End Sub

    Private Sub treeView1_AfterCollapse(ByVal sender As Object, ByVal e As LidorSystems.IntegralUI.ObjectEventArgs) Handles treeView1.AfterCollapse
        ' Change the icon of the node to show closed folder after node gets collapsed
        If TypeOf e.[Object] Is LidorSystems.IntegralUI.Lists.TreeNode Then
            Dim node As LidorSystems.IntegralUI.Lists.TreeNode = DirectCast(e.[Object], LidorSystems.IntegralUI.Lists.TreeNode)

            ' Set the same image when node is selected or not selected
            node.ImageIndex = 0
            node.SelectedImageIndex = 0
        End If
    End Sub
#End Region

End Class
