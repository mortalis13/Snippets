using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TestTreeViewThread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Holds the root node of the TreeView added last
        /// </summary>
        TreeNode tn;

        /// <summary>
        /// Fills up the TreeView.
        /// </summary>
        public void FillTree()
        {
            // Create 10 root nodes
            for (int i = 0; i < 10; i++)
            {
                //Create the node, here we must call on the form's thread otherwise we get an exception:
                //Action being performed on this control is being called from the wrong thread. Marshal 
                //to the correct thread using Control.Invoke or Control.BeginInvoke to perform this action.
                treeView1.Invoke(new Add(Add1), new object[] { i });
                //Create 10 subnodes for each root node
                for (int j = 0; j < 10; j++)
                {
                    //Create the node, here we must call on the form's thread otherwise we get an exception:
                    //Action being performed on this control is being called from the wrong thread. Marshal 
                    //to the correct thread using Control.Invoke or Control.BeginInvoke to perform this action.
                    treeView1.Invoke(new Add(Add2), new object[] { i * 10 + j });
                    //Slow down the filling process
                    System.Threading.Thread.Sleep(1000);
                }
                toolStripProgressBar1.PerformStep();
            }
            treeView1.Update();
        }

        public delegate void Add(int i);

        /// <summary>
        /// Adds a root node.
        /// </summary>
        /// <param name="i">Label of the new node.</param>
        public void Add1(int i)
        {
            tn = treeView1.Nodes.Add(i.ToString());
        }

        /// <summary>
        /// Adds a node under the current node.
        /// </summary>
        /// <param name="i">Label of the new node.</param>
        public void Add2(int i)
        {
            tn.Nodes.Add(i.ToString());
            treeView1.ExpandAll();
        }

        /// <summary>
        /// The filling thread's starting point
        /// </summary>
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            FillTree();
        }

        /// <summary>
        /// When form is loading
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            //Start filling the TreeView on a separate thread
            backgroundWorker1.RunWorkerAsync();
        }
    }
}